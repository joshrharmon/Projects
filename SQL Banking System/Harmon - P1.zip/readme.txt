readme:
- Steps to run:
	- Run create.sql for DDL
	- Compile java code
	- At this point you can run ProgramLauncher or P1.java
	- Make sure to change the IP in db.properties to the proper one
	- After done running, run drop.sql
- No other changes to report.